# Changelog

## 0.2.1 (Vendored lifecycle repair)

- Capture live webContents for cleanup after BrowserWindow destruction.
- Preserve shortcut, window, app, session preload and IPC ownership on close/disposal.
- Backported register.cjs from StoneHub/webDevFeedbackExt commit 5a0e413117c5bfc8b43fdb72dc1227a6a7701840.

## 0.2.0 (Release candidate)

- Added the development-only `@dev-feedback/electron/register` entrypoint.
- Reduced Host App integration to one guarded import before window creation.
- Moved the inspector preload, multi-window shortcut, IPC trust checks, and local History lifecycle into the package.
- Preserved existing session preloads and removed package hooks during explicit disposal.
- Kept packaged applications inert and production artifacts free to omit the development dependency.

